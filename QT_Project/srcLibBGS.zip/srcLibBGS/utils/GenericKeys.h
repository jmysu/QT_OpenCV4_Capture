#pragma once

namespace bgslibrary
{
  const int KEY_REPEAT = 'r';
  const int KEY_SPACE = 32;
  const int KEY_ESC = 27;
  const int KEY_ESC2 = 'q';
}
